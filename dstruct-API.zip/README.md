# Motivation

`To minimize the difference between the development and competitive programming. `

### Description

Built an API using flask and sqlite3 achieved the application functionality using different collections of data structure that we would probability while doing competitive programming.
