class Node:
    def __init__(self,data,next_node=None):
        self.data = data
        self.next_node = next_node

class Data:
    def __init__(self,key,value):
        self.key = key
        self.value = value

class HashTable:
    def __init__(self,table_size):
        self.table_size = table_size
        self.hash_table = [None]*table_size
    
    def custom_hash(self,key):
        hash_value = 0
        for i in key:
            hash_value += ord(i)
            hash_value = hash_value * ord(i) % self.table_size
        return hash_value
    
    def add_key_value_pair(self,key,value):
        hashed_key = self.custom_hash(key)
        # inserting the initial node
        if self.hash_table[hashed_key] is None:
            self.hash_table[hashed_key] = Node(data=Data(key,value),next_node=None)
        else:
            node = self.hash_table[hashed_key]
            while node.next_node:
                node = node.next_node
            node.next_node = Node(Data(key,value),None) # add the new node at last(tail)
            
    def get_value(self,key):
        hashed_key = self.custom_hash(key)
        if self.hash_table[hashed_key] is not None:
            node = self.hash_table[hashed_key]
            if node.next_node is None: # only single node(current at head)
                return node.data.value
            while node.next_node:
                if key == node.data.key:
                    return node.data.value
                node = node.next_node
            # for the last node
            if key == node.data.key:
                return node.data.value
        return None
    
    def print_table(self):
        res = ""
        res += "{"
        print("{")
        for i,val in enumerate(self.hash_table):
            if val is not None:
                llist_string = ""
                node = val
                if node.next_node:
                    while node.next_node:
                        llist_string += (
                            str(node.data.key) + " : " + str(node.data.value) + " --> "
                        )
                        node = node.next_node
                    # last node
                    llist_string += (
                        str(node.data.key) + " : " + str(node.data.value) + " --> None"
                    )
                    res += f"    [{i}] {llist_string}"
                    print(f"    [{i}] {llist_string}")
                else:
                    res += f"    [{i}] {val.data.key} : {val.data.value}"
                    print(f"    [{i}] {val.data.key} : {val.data.value}")
            else:
                res += f"    [{i}] {val}"
                print(f"    [{i}] {val}")
        res += "}"
        print("}")
        return res
                
             
            